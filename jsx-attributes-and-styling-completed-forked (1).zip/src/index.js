import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1 className="heading"> Favorite Pets</h1>
    <ul>
      <li>Cats </li>
      <li> Smol Cats </li>
      <li> Big Cats </li>
    </ul>
  </div>,

  document.getElementById("root")
);
