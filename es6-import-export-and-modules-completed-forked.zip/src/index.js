import React from "react";
import ReactDOM from "react-dom";
import PI, { doublePi, triplePi } from "./math.js";
//It doesn't matter if its PI in upper
//case because in the end the import
//will go to the {./math.js} and look
//for the default export.[One default export per file]
//but for others you have to be case-sensitive.
ReactDOM.render(
  <ul>
    <li>{PI}</li>
    <li>{doublePi()}</li>
    <li>{triplePi()}</li>
  </ul>,
  document.getElementById("root")
);
