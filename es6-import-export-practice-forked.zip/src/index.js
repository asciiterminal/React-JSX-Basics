import React from "react";
import ReactDOM from "react-dom";
import * as Calculator from "./calculator.js";
//{*} is a wildcard that enables the export of
//multiple fuunctions/modules into one file
//without the need of writing all of them.
//"One star to rule them all".

ReactDOM.render(
  <ul>
    <li>{Calculator.add(1, 2)}</li>
    <li>{Calculator.multiply(2, 3)}</li>
    <li>{Calculator.subtract(7, 2)}</li>
    <li>{Calculator.divide(5, 2)}</li>
  </ul>,
  document.getElementById("root")
);
