import React from "react";
import ReactDOM from "react-dom";

const img = "https://picsum.photos/200";
// for JSX you can create constant variables for image links
ReactDOM.render(
  <div>
    <h1 className="heading"> Favorite Pics</h1>
    <img alt="pci" src={img + "?grayscale"} />
  </div>,

  document.getElementById("root")
);
