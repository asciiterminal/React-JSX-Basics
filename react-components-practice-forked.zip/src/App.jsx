import React from "react";
import Heading from "./Heading.jsx";

function App() {
  return (
    <div>
      <Heading />
    </div>
  );
}

export default App;
